<head>
<script type="text/javascript">
<!--
   function helloWorld() {
      alert('Hello World!') ;
   }
 // -->
</script>
</head>